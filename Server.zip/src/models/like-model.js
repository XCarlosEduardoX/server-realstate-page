
import db from './../firebase.js';


class Like {
    constructor(idUser, idStory, idPost,

    ) {
        this.idUser = idUser;
        this.idStory = idStory;
        this.idPost = idPost;
    }


    //save a post
    newLike() {
        console.log(this.idUser, this.idStory, this.idPost);
        db.collection('POSTS').doc(this.idPost).get()
            .then((doc) => {
                if (doc.exists) {
                    let stories = doc.data().stories;

                    //buscar la historia por id
                    let story = stories.find(story => story.id === this.idStory);

                    //obtenemos los likes de la historia
                    let likes = story.like_users;

                    //verificar si el usuario ya dio like
                    let like = likes.find(like => like === this.idUser);

                    if (like) {
                        //si ya dio like, lo quitamos
                        likes = likes.filter(like => like !== this.idUser);
                    }
                    else {
                        //si no dio like, lo agregamos
                        likes.push(this.idUser);
                    }

                    //actualizamos los likes
                    story.like_users = likes;

                    //actualizamos la historia
                    stories[stories.indexOf(story)] = story;

                    //actualizamos el post
                    db.collection('POSTS').doc(this.idPost).update({
                        stories: stories
                    })
                        .then((docRef) => {
                            console.log('Like guardado');
                        })
                        .catch((error) => {
                            res.sendStatus(500);
                        });





                } else {
                    console.log('No such document!');
                }
            })
            .catch((error) => {
                console.log('Error getting document:', error);
            });


        // let storiesToAdd = [];
        // storiesToAdd = JSON.parse(this.stories)
        // let stories = FieldValue.arrayUnion(...storiesToAdd);
        // //de string a objeto
        // return new Promise((resolve, reject) => {
        //     db.collection('POSTS').doc(this.idAuthor).set({
        //         id: this.id,
        //         idAuthor: this.idAuthor,
        //         stories: stories,
        //         idDocument: this.idAuthor,
        //         //guardar la referencia del documento
        //         referece: db.collection('POSTS').doc(this.idAuthor)
        //     }, { merge: true })
        //         .then((docRef) => {
        //             resolve(docRef);

        //         })
        //         .catch((error) => {
        //             res.sendStatus(500);
        //         });
        // }
        // );
    }








}


export default Like;
