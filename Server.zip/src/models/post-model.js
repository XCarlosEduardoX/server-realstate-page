
import moment from 'moment';
import db from './../firebase.js';
import { FieldValue } from "firebase-admin/firestore"


class Post {
    constructor(idAuthor, stories, id,
    ) {
        this.id = id;
        this.idAuthor = idAuthor;
        this.stories = stories;

    }


    //save a post
    save() {
        //crear un array vacio
        let storiesToAdd = [];
        storiesToAdd = JSON.parse(this.stories)
        let stories = FieldValue.arrayUnion(...storiesToAdd);
        //de string a objeto
        return new Promise((resolve, reject) => {
            db.collection('POSTS').doc(this.idAuthor).set({
                id: this.id,
                idAuthor: this.idAuthor,
                stories: stories,
                idDocument: this.idAuthor,
                //guardar la referencia del documento
                referece: db.collection('POSTS').doc(this.idAuthor)
            }, { merge: true })
                .then((docRef) => {
                    this.lastUpdate(this.idAuthor);
                    resolve(docRef);
                })
                .catch((error) => {
                    res.sendStatus(500);
                });
        }
        );
    }

    //save a post
    setView() {
        //crear un array vacio
        let stories = JSON.parse(this.stories)
        //de string a objeto
        return new Promise((resolve, reject) => {
            db.collection('POSTS').doc(this.idAuthor).update({
                stories: stories
            })
                .then((docRef) => {
                    resolve(docRef);
                    console.log('Historias vistas: ', this.idAuthor);
                })
                .catch((error) => {
                    console.log('Error al actualizar historias vistas: ', error);
                });
        }
        );
    }



    lastUpdate(idAuthor) {
        return new Promise((resolve, reject) => {
            db.collection('POSTS').doc(idAuthor).update({
                lastUpdate: moment().format('')
            })
                .then((docRef) => {
                    resolve(docRef);
                })
                .catch((error) => {
                    reject(error);
                });
        });
    }





    //obtener todos los posts
    static getAll() {
        return new Promise((resolve, reject) => {
            db.collection('posts').get()
                .then((querySnapshot) => {
                    let posts = [];
                    querySnapshot.forEach((doc) => {
                        let post = doc.data();
                        post.id = doc.id;
                        posts.push(post);
                    });
                    resolve(posts);
                })
                .catch((error) => {
                    reject(error);
                });
        });
    }

    //obtener un post por id

    static getById(id) {
        return new Promise((resolve, reject) => {
            db.collection('posts').doc(id).get()
                .then((doc) => {
                    let post = doc.data();
                    post.id = doc.id;
                    resolve(post);
                })
                .catch((error) => {
                    reject(error);
                });
        });
    }

    //exportar la clase
}


export default Post;
