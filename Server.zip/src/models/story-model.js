
import db from './../firebase.js';
import { FieldValue } from "firebase-admin/firestore"


class Story {
    constructor(quote,
        comments,
        like_users,
        reports,
        viewers,
        active,
        datePublished,
        type,
        url,
        id,
    ) {
        this.id = id;
        this.quote = quote;
        this.comments = comments;
        this.like_users = like_users;
        this.reports = reports;
        this.viewers = viewers;
        this.active = active;
        this.datePublished = datePublished;
        this.type = type;
        this.url = url;
    }



 








    //exportar la clase
}


export default Story;
