import express from 'express';

const router = express.Router();




//importar el controlador
import postController from '../controllers/postController.js';
import storyController from '../controllers/storyController.js';




//exportar router como funcion
export default function () {

    //agregar nuevos posts via post
    router.post('/new-post', postController.newPost);

    //poner post en visto
    router.post('/new-view', postController.newView);

    //obtener todos los posts
    router.get('/posts', postController.getPosts);


    //like a story
    router.post('/story/like', storyController.newLike);
    router.get('/story/view/:id/:index', storyController.getStory);

    return router;
}


