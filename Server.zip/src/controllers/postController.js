import Post from '../models/post-model.js';


export default {
    newPost: async (req, res) => {
        const post = new Post(
            req.body.idAuthor,
            req.body.stories,
            req.body.id,
        );
        try {
            await post.save();
            res.json({ message: 'Post created successfully' });

        } catch (error) {
            console.log(error);
            res.json({ message: 'An error has ocurred' });
        }
    },
    newView: async (req, res) => {
        const post = new Post(
            req.body.idAuthor,
            req.body.stories,
            req.body.id,
        );
        try {
            await post.setView();
            res.json({ message: 'Post created successfully' });

        } catch (error) {
            console.log(error);
            res.json({ message: 'An error has ocurred' });
        }
    },
    getPosts: async (req, res) => {
        try {
            const posts = await Post.getAll();
            res.json(posts);
        } catch (error) {
            console.log(error);
            res.json({ message: 'An error has ocurred' });
        }
    }
}
