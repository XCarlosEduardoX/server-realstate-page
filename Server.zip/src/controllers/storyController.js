import Like from '../models/like-model.js';
import Story from '../models/story-model.js';
import db from './../firebase.js';

function getTheStory(idPost, index) {
    console.log("idPost: ", idPost, "index: ", index);
    return new Promise((resolve, reject) => {
        db.collection('POSTS').doc(idPost).get().then((doc) => {
            if (doc.exists) {
                let stories = [] = doc.data().stories;
                console.log(stories);
                resolve(stories[index]);
            } else {
                reject('No such document!');
            }
        }).catch((error) => {
            reject('Error getting document:', error);
            console.log(error);
        });
    });                                                                             
}

export default {
    newLike: async (req, res) => {
        const like = new Like(
            req.body.idUser,
            req.body.idStory,
            req.body.idPost,
        );
        try {
            like.newLike();
            res.json({ message: 'Post created successfully' });

        } catch (error) {
            console.log(error);
            res.json({ message: 'An error has ocurred' });
        }
    },
    getStory: async (req, res) => {
        const { id, index } = req.params;
        console.log(id, index);
        try {
            const story = await getTheStory(id, index);
            res.json(story);
        } catch (error) {
            console.log(error);
            res.json({ message: 'An error has ocurred' });
        }


    }
}
